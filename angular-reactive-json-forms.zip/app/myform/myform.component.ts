import { Component, OnInit } from '@angular/core';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-myform',
  templateUrl: 'myform.component.html'
})
export class MyformComponent implements OnInit {
  form = new FormGroup({}); //form group 
  model = {}; //mode declaration 
  fields: FormlyFieldConfig[]; //form fields 
  allfields: Array<any> = []; //all fields to bind 
  postURL: string; //URL to post data from JSON 

  constructor(private http: HttpClient) {
    this.getJSON().subscribe(data => {
      let length = data.schema.length;
      this.postURL = data.postURL;
      for (let i in data.schema) {

        //start-- defining a textbox 

        if (data.schema[i].Type == 'textbox') {

          this.allfields.push({
            key: data.schema[i].name,
            type: 'input',

            templateOptions: {
              type: data.schema[i].Type,
              label: data.schema[i].Label,
              name: data.schema[i].Group,
              value: data.schema[i].Default,
              placeholder: data.schema.HelpText,
              required: true,
            }
          })
        }
        //end - defining a textbox 

        //start - defining a radio button 

        if (data.schema[i].Type == 'radio') {

          this.allfields.push({
            key: data.schema[i].name,
            type: 'radio',
            ngModelElAttrs: {
              tabindex: '1'
            },

            templateOptions: {
              type: data.schema[i].Type,
              label: data.schema[i].Label,
              name: data.schema[i].Group,

              placeholder: data.schema.HelpText,
              required: true,
              options: [

                {
                  key: data.schema[i].Default,
                  value: data.schema[i].Label,

                },

              ]
            }
          })
        }

        //end - defining a radio button 

        //start - defining a checkbox 
        if (data.schema[i].Type == 'checkbox') {

          this.allfields.push({
            key: data.schema[i].name,
            type: 'checkbox',
            ngModelElAttrs: {
              tabindex: '1'
            },

            templateOptions: {
              type: data.schema[i].Type,
              label: data.schema[i].Label,
              name: data.schema[i].Group,
              value: data.schema[i].Default,
              placeholder: data.schema.HelpText,
              required: true,
              options: [

                { key: 'ida', value: 'test' }

              ]
            }
          })
        }
        //end - defining a radio button 



        // console.log(this.allfields);

      }


      this.fields = this.allfields;

    });


  }

  public getJSON(): Observable<any> {
    return this.http.get("/assets/data.json")
  }

  ngOnInit() {
  }

  submit() {
    console.log(this.model);

    this.http.post(this.postURL, this.model).subscribe(resp => console.log(resp), err => console.log(err));
  }
}
