import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IEmployee } from './IEmployee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  public data_url = '/assets/data.json';

  days: any[];

  public mydata: IEmployee[];
  constructor(private http: HttpClient, private formBuilder: FormBuilder) {

  }
  public detailsForm: FormGroup;
  gender = 'male';
  url = '/assets/data.json';
  schema;


  loadFile() {

  }


  public ngOnInit() {
    let daysFormGroup: FormGroup = new FormGroup({});
    this.http.get<any[]>(this.url).subscribe(resp => {
      this.days = resp["schema"];
      for (let day of this.days) {
        console.log('hi' + day.name);
        let control: FormControl = new FormControl(day.name, Validators.required);
        daysFormGroup.addControl(day.name, control);

      }
    }, err => console.log(err));


    //create detailsForm FormGroup using FormBuilder's short-hand syntax
    this.detailsForm = this.formBuilder.group({
      name: ["", Validators.required],
      days: daysFormGroup
    });
  }




  onSubmit() {
    console.log(this.detailsForm.value.days);
  }




}
