export interface IEmployee {
    Type: any;
    Group?: any;
    name?: any;
    HelpText?: any;
    Required?: any;
    Label?: any;

}